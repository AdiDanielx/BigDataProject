/**
 * 
 */
package org.bgu.ise.ddb.items;

import java.io.IOException;
import java.io.*;
import java.net.*;

import javax.servlet.http.HttpServletResponse;

import org.bgu.ise.ddb.MediaItems;
import org.bgu.ise.ddb.ParentController;
import org.bgu.ise.ddb.User;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

import com.mongodb.BasicDBObject;
import com.mongodb.DB;
import com.mongodb.DBCollection;
import com.mongodb.DBCursor;
import com.mongodb.DBObject;
import com.mongodb.MongoClient;
import com.mongodb.client.MongoCollection;
import com.mongodb.client.MongoDatabase;
import java.sql.Statement;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.sql.ResultSet;

/**
 * @author Alex
 *
 */
@RestController
@RequestMapping(value = "/items")
public class ItemsController extends ParentController {
	
	
	
	/**
	 * The function copy all the items(title and production year) from the Oracle table MediaItems to the System storage.
	 * The Oracle table and data should be used from the previous assignment
	 */
	@RequestMapping(value = "fill_media_items", method={RequestMethod.GET})
	public void fillMediaItems(HttpServletResponse response){
		System.out.println("was here");
		Connection conn  = null;
		MongoClient mongoClient = null;
		//:TODO your implementation
		try {
			String username = "daniel7";
			String password = "*h9nZ/px";
			Class.forName("com.microsoft.sqlserver.jdbc.SQLServerDriver");
		    String url = "jdbc:sqlserver://132.72.64.124:1433;databaseName=" + username + ";user=" + username + ";password={" + password + "};encrypt=false;";
		    conn = DriverManager.getConnection(url);
		    
		    mongoClient = new MongoClient("localhost",27017);
		    DB db = mongoClient.getDB("BigDataProject");
			DBCollection medias = db.getCollection("MediaItems");

            String sqlQuery = "SELECT * FROM MediaItems";
		    Statement stmt = conn.createStatement();
		    ResultSet rs = stmt.executeQuery(sqlQuery);
		    while (rs.next()) {
		        String title = rs.getString("title");
		        int prodYear = rs.getInt("PROD_YEAR");
		        BasicDBObject existingMedia = new BasicDBObject("title", title).append("PROD_YEAR", prodYear);
	            if (medias.findOne(existingMedia) == null) {
		        BasicDBObject newMedia = new BasicDBObject();
		        newMedia.put("title", title);
		        newMedia.put("PROD_YEAR", prodYear);
		        medias.insert(newMedia);
		        response.setStatus(HttpStatus.OK.value());
	            }
		    }
		    mongoClient.close();
			HttpStatus status = HttpStatus.OK;
			response.setStatus(status.value());

		}
		 catch (ClassNotFoundException e) {
		        e.printStackTrace();
		        response.setStatus(HttpStatus.INTERNAL_SERVER_ERROR.value());
		    } catch (Exception e) {
		        e.printStackTrace();
		        response.setStatus(HttpStatus.INTERNAL_SERVER_ERROR.value());
		    }
		finally {
	        if (mongoClient != null) {
	            mongoClient.close();
	        }
	        if (conn != null) {
                try {
                    conn.close();
                } catch (SQLException e) {
                    throw new RuntimeException(e);
                }
		}
		}
	}
	

	/**
	 * The function copy all the items from the remote file,
	 * the remote file have the same structure as the films file from the previous assignment.
	 * You can assume that the address protocol is http
	 * @throws IOException 
	 */
	@RequestMapping(value = "fill_media_items_from_url", method={RequestMethod.GET})
	public void fillMediaItemsFromUrl(@RequestParam("url")    String urladdress,
			HttpServletResponse response) throws IOException{
		System.out.println(urladdress);
		MongoClient mongoClient = null;
		//:TODO your implementation
		try {
		    mongoClient = new MongoClient("localhost",27017);
		    DB db = mongoClient.getDB("BigDataProject");
			DBCollection medias = db.getCollection("MediaItems");
			URL url = new URL(urladdress);
			BufferedReader read = new BufferedReader(new InputStreamReader(url.openStream()));
			String i ;
			while ((i = read.readLine()) != null)
			{
	            String[] fields = i.split(",");
                String title = fields[0].trim();
                int prodYear = Integer.parseInt(fields[1].trim());
		        BasicDBObject existingMedia = new BasicDBObject("title", title).append("PROD_YEAR", prodYear);
	            if (medias.findOne(existingMedia) == null) {
		        BasicDBObject newMedia = new BasicDBObject();
		        newMedia.put("title", title);
		        newMedia.put("PROD_YEAR", prodYear);
		        medias.insert(newMedia);
	            }
			}
		    read.close();
		    mongoClient.close();
			HttpStatus status = HttpStatus.OK;
			response.setStatus(status.value());

		}
		catch (IOException e) {
        e.printStackTrace();
        response.setStatus(HttpStatus.INTERNAL_SERVER_ERROR.value());
    }
		finally {
	        if (mongoClient != null) {
	            mongoClient.close();
	        }
		}

	}
	
	
	/**
	 * The function retrieves from the system storage N items,
	 * order is not important( any N items) 
	 * @param topN - how many items to retrieve
	 * @return
	 */
	@RequestMapping(value = "get_topn_items",headers="Accept=*/*", method={RequestMethod.GET},produces="application/json")
	@ResponseBody
	@org.codehaus.jackson.map.annotate.JsonView(MediaItems.class)
	public  MediaItems[] getTopNItems(@RequestParam("topn")    int topN){
		//:TODO your implementation
		 MongoClient mongoClient = new MongoClient("localhost",27017);
		 DB db = mongoClient.getDB("BigDataProject");
		 DBCollection medias = db.getCollection("MediaItems");
	     DBCursor cursor = medias.find();
	     long count_m = medias.count();
	     int count = (int) count_m;
	     int i =0;
	     MediaItems[] movieArray = new MediaItems[count];
		 while (cursor.hasNext() && i < topN) {
			 DBObject movie = cursor.next();
	         String title = (String) movie.get("title");
	         int prod_year = (int) movie.get("PROD_YEAR");
	         MediaItems med = new MediaItems(title,prod_year);
	         movieArray[i]= med;
	         i ++;
		 }
		 mongoClient.close();
		 return movieArray;
	}
		

}
