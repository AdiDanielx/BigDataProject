/**
 * 
 */
package org.bgu.ise.ddb.registration;



import java.io.IOException;
import java.time.*;
import java.time.format.DateTimeFormatter;

import java.util.Calendar;

import javax.servlet.http.HttpServletResponse;

import org.bgu.ise.ddb.ParentController;
import org.bgu.ise.ddb.User;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;
import com.mongodb.*;
import java.util.Date;
import java.text.SimpleDateFormat;
/**
 * @author Alex
 *
 */
@RestController
@RequestMapping(value = "/registration")
public class RegistarationController extends ParentController{
	/**
	 * The function checks if the username exist,
	 * in case of positive answer HttpStatus in HttpServletResponse should be set to HttpStatus.CONFLICT,
	 * else insert the user to the system  and set to HttpStatus in HttpServletResponse HttpStatus.OK
	 * @param username
	 * @param password
	 * @param firstName
	 * @param lastName
	 * @param response
	 */
	@RequestMapping(value = "register_new_customer", method={RequestMethod.POST})
	public void registerNewUser(@RequestParam("username") String username,
			@RequestParam("password")    String password,
			@RequestParam("firstName")   String firstName,
			@RequestParam("lastName")  String lastName,
			HttpServletResponse response){
		System.out.println(username+" "+password+" "+lastName+" "+firstName);
		//:TODO your implementation
		MongoClient mongoClient = null;
		try {
			mongoClient = new MongoClient("localhost",27017);
			DB db = mongoClient.getDB("BigDataProject");
			DBCollection users = db.getCollection("Users");
			BasicDBObject query = new BasicDBObject();
            query.put("password", password);
            query.put("firstName", firstName);
            query.put("lastName", lastName);
            DBObject existingUser = users.findOne(query);

			if (!isExistUser(username)) {
            	DBObject newUser = new BasicDBObject();
                newUser.put("username", username);
                newUser.put("password", password);
                newUser.put("firstName", firstName);
                newUser.put("lastName", lastName);
                SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd");
                String registrationDate = dateFormat.format(new Date());
                newUser.put("registrationDate", registrationDate);


                users.insert(newUser);
                response.setStatus(HttpStatus.OK.value());
            }
            else {
                response.setStatus(HttpStatus.CONFLICT.value());

            }	
			mongoClient.close();
			HttpStatus status = HttpStatus.OK;
			response.setStatus(status.value());

		}
		catch (Exception e) {
            e.printStackTrace();
            response.setStatus(HttpStatus.INTERNAL_SERVER_ERROR.value());
        }
		finally {
	        if (mongoClient != null) {
	            mongoClient.close();
	        }
		}
	}
	
	/**
	 * The function returns true if the received username exist in the system otherwise false
	 * @param username
	 * @return
	 * @throws IOException
	 */
	@RequestMapping(value = "is_exist_user", method={RequestMethod.GET})
	public boolean isExistUser(@RequestParam("username") String username) throws IOException{
		System.out.println(username);
		boolean result = false;
		//:TODO your implementation
		MongoClient mongoClient = null;
		try {
			mongoClient = new MongoClient("localhost",27017);
			DB db = mongoClient.getDB("BigDataProject");
			DBCollection users = db.getCollection("Users");
			BasicDBObject query = new BasicDBObject();
		    query.put("username", username);
		    DBObject existingUser = users.findOne(query);
		    if (existingUser != null) {
		        result = true; 
		    }
			mongoClient.close();

		} 
		catch (Exception e) {
		    e.printStackTrace();
		}
		finally {
	        if (mongoClient != null) {
	            mongoClient.close();
	        }
		}
		return result;
	}
	
	/**
	 * The function returns true if the received username and password match a system storage entry, otherwise false
	 * @param username
	 * @return
	 * @throws IOException
	 */
	@RequestMapping(value = "validate_user", method={RequestMethod.POST})
	public boolean validateUser(@RequestParam("username") String username,
			@RequestParam("password")    String password) throws IOException{
		System.out.println(username+" "+password);
		boolean result = false;
		//:TODO your implementation
		MongoClient mongoClient = null;
		try {
			mongoClient = new MongoClient("localhost",27017);
			DB db = mongoClient.getDB("BigDataProject");
			DBCollection users = db.getCollection("Users");
			BasicDBObject myQuery = new BasicDBObject();
			myQuery.put("username", username);
			myQuery.put("password", password);
			DBCursor cursor = users.find(myQuery);
			if (cursor.count() !=0) {
				result = true;
			}
			mongoClient.close();
		}
		catch(MongoException e){
			e.printStackTrace();
			
		}
		finally {
	        if (mongoClient != null) {
	            mongoClient.close();
	        }
		}
		return result;
		
	}
	
	/**
	 * The function retrieves number of the registered users in the past n days
	 * @param days
	 * @return
	 * @throws IOException
	 */
	@RequestMapping(value = "get_number_of_registred_users", method={RequestMethod.GET})
	public int getNumberOfRegistredUsers(@RequestParam("days") int days) throws IOException{
		System.out.println(days+"");
		int result = 0;
		MongoClient mongoClient = null;
		//:TODO your implementation
		try {
	        mongoClient = new MongoClient("localhost", 27017);
	        DB db = mongoClient.getDB("BigDataProject");
	        DBCollection users = db.getCollection("Users");

	        LocalDate startDate = LocalDate.now().minusDays(days); // Subtract 1 day to include the current day
	        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd");
	        String formattedStartDate = startDate.format(formatter);

	        BasicDBObject query = new BasicDBObject();
	        query.put("registrationDate", new BasicDBObject("$gte", formattedStartDate));
	        result = users.find(query).count();
	        mongoClient.close();
	    } catch (Exception e) {
	        e.printStackTrace();
	    }
		finally {
	        if (mongoClient != null) {
	            mongoClient.close();
	        }
		}
		
	    return result;
	}
	 
	/**
	 * The function retrieves all the users
	 * @return
	 */
	@RequestMapping(value = "get_all_users",headers="Accept=*/*", method={RequestMethod.GET},produces="application/json")
	@ResponseBody
	@org.codehaus.jackson.map.annotate.JsonView(User.class)
	public  User[] getAllUsers(){
		//:TODO your implementation
		MongoClient mongoClient = null;
		    try {
		        mongoClient = new MongoClient("localhost",27017);
				DB db = mongoClient.getDB("BigDataProject");
				DBCollection users = db.getCollection("Users");
		        DBCursor cursor = users.find();
		        long count_u = users.count();
		        int count = (int) count_u;
		        int counter = 0;
		        User[] usersArray = new User[count];
		        while (cursor.hasNext()) {
		            DBObject userObj = cursor.next();
		            String username = (String) userObj.get("username");
		            String password = (String) userObj.get("password");
		            String firstName = (String) userObj.get("firstName");
		            String lastName = (String) userObj.get("lastName");
		            
		            User user = new User(username, password, firstName, lastName);
		           // System.out.println(user);
		            usersArray[counter] = user;
		            counter ++;
		    }
		        mongoClient.close();
			    return usersArray;
		    }
		    catch (Exception e) {
		        e.printStackTrace();
		    }
		    finally {
		        if (mongoClient != null) {
		            mongoClient.close();
		        }
			}
		    return new User[0];
		}


}
